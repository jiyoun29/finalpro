import pandas as pd 
import os
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from functools import wraps
from datetime import datetime
from data_loader import load_users, load_movies, load_event_data, get_db_connection, load_and_preprocess_interactions, load_user_and_movie_ids
from model import load_or_initialize_model, recommend_similar_movies
import sqlite3
import cx_Oracle

app = Flask(__name__)
app.secret_key = "your_secret_key" #os.urandom(24) # 세션 데이터 암호화(임의 24바이트 문자열 지정)

# 모델 초기화
user_ids, movie_ids = load_user_and_movie_ids()
num_users = len(user_ids)
num_movies = len(movie_ids)
model = load_or_initialize_model(num_users, num_movies)

#db 연결 11/07 ---------------------------
# 데이터베이스 연결 정보
dsn = cx_Oracle.makedsn("localhost", 1521, sid="xe")
connection = cx_Oracle.connect("c##scott", "tiger", dsn)
#db 연결 11/07 ---------------------------

# 로그인 확인 데코레이터
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user" not in session:  # 세션에 'user' 키가 없으면 로그인 페이지로 리다이렉트
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

# 사용자 로그인 확인 함수
def login_user(account_id, user_df):
    user = user_df[user_df['ACCOUNT_ID'] == account_id]
    if not user.empty:
        return user.iloc[0]
    return None

# 기본 페이지 라우트
@app.route("/")
def index():
    # 세션에 'user'가 없을 경우 로그인 페이지로 이동
    if "user" not in session:
        return redirect(url_for("login"))  # 로그인하지 않은 경우 로그인 페이지로 이동
    return redirect(url_for("recommend"))  # 로그인한 경우 추천 페이지로 이동


# 로그인 페이지
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        account_id = request.form.get("account_id")
        user_df = load_users()

        # ACCOUNT_ID에 해당하는 USER_ID 조회
        user = user_df[user_df['ACCOUNT_ID'] == account_id]
        if not user.empty:
            user_id = user.iloc[0]['USER_ID']  # USER_ID 가져오기
            session['user_id'] = user_id       # 세션에 USER_ID 저장
            session['account_id'] = account_id # 세션에 ACCOUNT_ID 저장 (선택적)
            # print("로그인 성공: 세션에 사용자 ID 저장됨")  # 디버깅 로그
            
            # 로그인 후 이동할 default 페이지 설정
            return redirect(url_for("movies"))
        else:
            flash("로그인 실패: 잘못된 Account ID입니다.")
            return redirect(url_for("login"))

    return render_template("login.html")

# 회원가입 11/07 추가 -----------------------------
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        account_id = request.form['account_id']
        gender = request.form['gender']
        age = request.form['age']

        # 데이터베이스 연결
        try:
            connection = cx_Oracle.connect("c##scott", "tiger", "localhost:1521/xe")
            with connection.cursor() as cursor:
                
                # account_id 중복 확인
                cursor.execute("SELECT COUNT(*) FROM USER_TABLE WHERE ACCOUNT_ID = :1", (account_id,))
                account_id_count = cursor.fetchone()[0]

                if account_id_count > 0:
                    flash('이미 사용 중인 아이디입니다. 다른 아이디를 선택해 주세요.', 'danger')
                    return redirect(url_for('signup'))
                
                # USER_ID 자동 부여 로직
                cursor.execute("SELECT MAX(USER_ID) FROM USER_TABLE WHERE USER_ID LIKE 'IW%'")
                max_user_id = cursor.fetchone()[0]

                if max_user_id:
                    new_id_num = int(max_user_id[2:]) + 1  # "IW"를 제외하고 숫자 부분만 가져와 증가
                    new_user_id = f"IW{new_id_num:03d}"  # 새로운 ID 형식 IW###로 설정
                else:
                    new_user_id = "IW001"  # 첫 사용자인 경우 IW001로 설정

                # 회원 정보 삽입
                cursor.execute(
                    "INSERT INTO USER_TABLE (USER_ID, ACCOUNT_ID, GENDER, AGE) VALUES (:1, :2, :3, :4)",
                    (new_user_id, account_id, gender, age)
                )
                connection.commit()
                flash('회원가입이 완료되었습니다! 이제 로그인해 주세요.', 'success')
                
                # 로그인 페이지로 리디렉션
                return redirect(url_for('login'))

        except cx_Oracle.Error as e:
            flash(f'회원가입 중 오류가 발생했습니다: {e}', 'danger')
        
        finally:
            if connection:
                connection.close()

    return render_template('signup.html')


# 회원가입 11/07 추가 -----------------------------

# 로그아웃 기능
@app.route("/logout")
def logout():
    session.pop("user_id", None)  # 세션에서 'user' 제거
    return redirect(url_for("login"))


#11/8 수정
def save_event(user_id, movie_id, event_type, event_value):
    conn = get_db_connection()
    current_time = datetime.now()
    try:
        cursor = conn.cursor()
        
        # 기존 좋아요 이벤트 확인
        cursor.execute("""
            SELECT EVENT_ID FROM ACTION 
            WHERE USER_ID = :user_id AND MOVIE_ID = :movie_id AND EVENT_TYPE = :event_type
        """, {
            'user_id': user_id,
            'movie_id': movie_id,
            'event_type': event_type
        })
        existing_event = cursor.fetchone()
        
        if existing_event:
            # 기존 좋아요 값 업데이트
            cursor.execute("""
                UPDATE ACTION 
                SET EVENT_VALUE = :event_value, EVENT_TIMESTAMP = :timestamp 
                WHERE EVENT_ID = :event_id
            """, {
                'event_value': event_value,
                'timestamp': current_time,
                'event_id': existing_event[0]
            })
        else:
            # 새로운 좋아요 이벤트 삽입, 초기값 1로 설정
            cursor.execute("""
                INSERT INTO ACTION (USER_ID, MOVIE_ID, EVENT_TYPE, EVENT_VALUE, EVENT_TIMESTAMP) 
                VALUES (:user_id, :movie_id, :event_type, :event_value, :timestamp)
            """, {
                'user_id': user_id,
                'movie_id': movie_id,
                'event_type': event_type,
                'event_value': 1,  # 새 이벤트는 항상 1로 설정
                'timestamp': current_time
            })

        conn.commit()
        print("Event saved successfully.")

    except cx_Oracle.DatabaseError as e:
        print(f"Database error: {e}")
        conn.rollback()
    finally:
        conn.close()



        
# 영화 목록 페이지
@app.route("/movies")
def movies():
    # 로그인 확인: 세션에 user_id가 있는지 확인
    if "user_id" not in session:
        flash("세션이 유효하지 않습니다. 코드를 재확인해주세요.")
        return redirect(url_for("login"))
    
    user_id = session.get("user_id")  # 세션에서 사용자 ID 가져오기 (선택적으로 사용)

    page = request.args.get('page', 1, type=int)
    per_page = 30  # 페이지 당 영화 수
    movies = load_movies()
    total_movies = len(movies)
    paginated_movies = movies[(page - 1) * per_page:page * per_page]
    total_pages = (total_movies + per_page - 1) // per_page

    # 페이지 번호 범위 설정
    start_page = max(1, page - 2)
    end_page = min(total_pages, page + 2)
    page_range = list(range(start_page, end_page + 1))

    # 추가적으로 user_id 기반의 사용자 맞춤 데이터 처리 가능
    # 예: 추천 영화를 로드하거나 사용자 맞춤 정보를 보여줄 때 사용 가능

    return render_template(
        "movies.html", 
        movies=paginated_movies, 
        page=page, 
        total_pages=total_pages, 
        page_range=page_range
    )

# 영화추천

@app.route("/recommend")
def recommend():
    if "user_id" not in session:
        return redirect(url_for("login"))

    user_id = session["user_id"]
    interactions = load_and_preprocess_interactions()

    # interactions 데이터 확인
    print("Interactions Head:")
    print(interactions.head())

    if 'USER_CODE' not in interactions.columns:
        flash("추천 데이터를 로드할 수 없습니다.")
        return redirect(url_for("movies"))

    user_code = interactions.loc[interactions['USER_ID'] == user_id, 'USER_CODE'].values
    if len(user_code) == 0:
        flash("추천할 영화가 없습니다.")
        return redirect(url_for("movies"))

    user_code = user_code[0]  # 첫 번째 값 사용
    movies = load_movies()

    # 영화 데이터 디버깅
    print("Movies Loaded:")
    print(movies[:5])  # 처음 5개의 영화만 출력

    recommended_movies = recommend_similar_movies(model, interactions, movies, user_code)

    # 추천 영화 디버깅
    print("Recommended Movies:")
    print(recommended_movies)

    if not recommended_movies:
        flash("추천할 영화가 없습니다.")
        return redirect(url_for("movies"))

    return render_template("recommend.html", movies=recommended_movies)

# 상호작용 처리 라우트
@app.route('/handle_event', methods=['POST'])
@login_required
def handle_event():
    data = request.json
    event_type = data.get('event_type')
    event_value = data.get('event_value')
    movie_id = data.get('movie_id')
    user_id = session.get('user_id')  # 세션에서 user_id 가져오기

    if not user_id:
        return jsonify({'error': 'User not logged in'}), 403

    response = {}

    if event_type == 'like':
        # 좋아요 상태 토글
        new_value = 1 if event_value == 0 else 0
        response['event_value'] = new_value
        response['icon'] = '♥' if new_value == 1 else '♡'
        save_event(user_id, movie_id, 'like', new_value)

    print("Event handled successfully")  # 성공 메시지 로깅
    return jsonify(response), 200



if __name__ == "__main__":
    app.run(debug=True) 