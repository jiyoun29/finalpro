import pandas as pd
import os
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
from functools import wraps
from datetime import datetime
from data_loader import load_users, load_movies,  get_db_connection, load_and_preprocess_interactions, load_user_and_movie_ids #load_event_data(미호출)
from model import load_or_initialize_model, calculate_movie_ranking, recommend_movies # 11/11 모델 추가
import cx_Oracle
from datetime import timedelta # 11/10 추가

app = Flask(__name__)
app.secret_key = "your_secret_key" #os.urandom(24) # 세션 데이터 암호화(임의 24바이트 문자열 지정)

# 세션 지속 시간 설정 (# 11/10 추가---------------)
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=30)  # 세션이 30분간 유지되도록 설정

# 데이터베이스 연결 정보 (# 11/7 추가--------------)
dsn = cx_Oracle.makedsn("localhost", 1521, sid="xe")
connection = cx_Oracle.connect("c##scott", "tiger", dsn)

# 모델 초기화
user = load_users()
user_ids, movie_ids = load_user_and_movie_ids()
num_users = len(user_ids)
num_movies = len(movie_ids)
model = load_or_initialize_model(num_users, num_movies)

# 로그인 확인 데코레이터
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if "user" not in session:  # 세션에 'user' 키가 없으면 로그인 페이지로 리다이렉트
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function

# 사용자 로그인 확인 함수
def login_user(account_id, user_df):
    user = user_df[user_df['ACCOUNT_ID'] == account_id]
    if not user.empty:
        return user.iloc[0]
    return None

# 디폴트 페이지 라우트
@app.route("/")
def index():
    # 세션에 'user'가 없을 경우 로그인 페이지로 이동
    if "user" not in session:
        return redirect(url_for("login"))  # 로그인하지 않은 경우 로그인 페이지로 이동
    return redirect(url_for("movies"))  # 로그인한 경우 전체 영화 페이지로 이동
    

# 로그인 페이지
# login 함수 수정 11/10
@app.route("/login", methods=["GET", "POST"])
def login():
    # 이미 로그인된 상태라면 movies로 리다이렉트
    if "user_id" in session:
        return redirect(url_for("movies"))
    
    if request.method == "POST":
        account_id = request.form.get("account_id")
        user_df = load_users() #사용자 데이터 로드

        # 디버그: 데이터프레임 출력
        print("User DataFrame:", user_df.head())

        if isinstance(user_df, pd.DataFrame):
            user = user_df[user_df['ACCOUNT_ID'] == account_id]

            print("User found:", user)  # 디버깅용 출력
            
            if not user.empty:
                user_id = user.iloc[0]['USER_ID']
                session['user_id'] = user_id
                session['user'] = {'ACCOUNT_ID' : account_id} # 값 추가 
                # session['user'] = user.to_dict()
                session['account_id'] = account_id
                return redirect(url_for("movies"))
            else:
                flash("로그인 실패: 잘못된 Account ID입니다.")
                return redirect(url_for("login"))
        else:
            flash("사용자 데이터 로드에 문제가 발생했습니다.")
            return redirect(url_for("login"))

    return render_template("login.html")


# BEGIN 회원가입 (#11/07 추가 -----------------------------)
@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        account_id = request.form['account_id']
        gender = request.form['gender']
        age = request.form['age']

        # 데이터베이스 연결
        try:
            connection = cx_Oracle.connect("c##scott", "tiger", "localhost:1521/xe")
            with connection.cursor() as cursor:
                
                # account_id 중복 확인
                cursor.execute("SELECT COUNT(*) FROM USER_TABLE WHERE ACCOUNT_ID = :1", (account_id,))
                account_id_count = cursor.fetchone()[0]

                if account_id_count > 0:
                    flash('이미 사용 중인 아이디입니다. 다른 아이디를 선택해 주세요.', 'danger')
                    return redirect(url_for('signup'))
                
                # USER_ID 자동 부여 로직
                cursor.execute("SELECT MAX(USER_ID) FROM USER_TABLE WHERE USER_ID LIKE 'IW%'")
                max_user_id = cursor.fetchone()[0]

                if max_user_id:
                    new_id_num = int(max_user_id[2:]) + 1  # "IW"를 제외하고 숫자 부분만 가져와 증가
                    new_user_id = f"IW{new_id_num:03d}"  # 새로운 ID 형식 IW###로 설정
                else:
                    new_user_id = "IW001"  # 첫 사용자인 경우 IW001로 설정

                # 회원 정보 삽입
                cursor.execute(
                    "INSERT INTO USER_TABLE (USER_ID, ACCOUNT_ID, GENDER, AGE) VALUES (:1, :2, :3, :4)",
                    (new_user_id, account_id, gender, age)
                )
                connection.commit()
                flash('회원가입이 완료되었습니다! 이제 로그인해 주세요.', 'success')
                
                # 로그인 페이지로 리디렉션
                return redirect(url_for('login'))

        except cx_Oracle.Error as e:
            flash(f'회원가입 중 오류가 발생했습니다: {e}', 'danger')
        
        finally:
            if connection:
                connection.close()

    return render_template('signup.html')
# END 회원가입 # 11/07 추가 -----------------------------)


# 검색창 (# 11/08 추가 -----------------------------)
@app.route("/search", methods=["GET"])
def search_movies():
    # 로그인 확인: 세션에 user_id가 있는지 확인
    if "user_id" not in session:
        flash("세션이 유효하지 않습니다. 코드를 재확인해주세요.")
        return redirect(url_for("login"))
    
    user_id = session.get("user_id")  # 세션에서 사용자 ID 가져오기 (선택적으로 사용)
    query = request.args.get("query", "")  # 검색어 가져오기
    page = request.args.get("page", 1, type=int)
    per_page = 30  # 페이지 당 영화 수

    # 모든 영화 목록을 로드 (전체 영화 목록을 가져오는 함수 사용)
    movies = load_movies()  # 여기에 적합한 함수로 영화 목록을 불러오세요
    
    # 절대 지우지마세요!!
    # DataFrame이 반환되었을 경우, 딕셔너리 리스트로 변환 (# 11/11 추가)  
    if isinstance(movies, pd.DataFrame):
        movies = movies.to_dict('records')

    # 검색어가 있으면 해당 영화 이름 또는 장르에 맞는 결과만 필터링 (#11/11 수정 ----)
    if query:
        movies = [
            movie for movie in movies 
            if query.lower() in movie["MOVIE_NAME"].lower() or query.lower() in movie["GENRE_NAME"].lower()
        ]

    # 이미지 경로 설정
    for movie in movies:
        image_path = os.path.join("static/images", f"{movie['MOVIE_NAME']}.jpg")
        if os.path.exists(image_path):
            movie["IMAGE_PATH"] = image_path
        else:
            movie["IMAGE_PATH"] = "static/images/default.jpg"  # 기본 이미지 경로 설정

    total_movies = len(movies)  # 필터링된 영화의 개수
    paginated_movies = movies[(page - 1) * per_page : page * per_page]  # 페이지네이션 처리
    total_pages = (total_movies + per_page - 1) // per_page  # 전체 페이지 수 계산

    # 페이지 번호 범위 설정 # 중복호출로 제거함
    start_page = max(1, page - 2)
    end_page = min(total_pages, page + 2)
    page_range = list(range(start_page, end_page + 1))

    return render_template(
        "search_results.html", 
        movies=paginated_movies, 
        query=query, 
        page=page, 
        total_pages=total_pages, 
        page_range=page_range
    )

# 검색창 11/08 추가 -----------------------------

# 로그아웃 기능
@app.route("/logout")
def logout():
    session.clear()  # 모든 세션 데이터 제거
    return redirect(url_for("login"))

# 이벤트 데이터 저장 라우터 (# 11/10 수정 ---------------- 
def save_event(user_id, movie_id, event_type, event_value):
    conn = get_db_connection()  # Oracle DB 연결
    current_time = datetime.now()
    try:
        cursor = conn.cursor()
        
        # 이벤트가 이미 존재하는지 확인
        cursor.execute("""
            SELECT EVENT_ID FROM ACTION 
            WHERE USER_ID = :user_id AND MOVIE_ID = :movie_id AND EVENT_TYPE = :event_type
        """, {
            'user_id': user_id,
            'movie_id': movie_id,
            'event_type': event_type
        })
        existing_event = cursor.fetchone()
        
        if existing_event:
            # 기존 이벤트가 있을 경우 업데이트
            cursor.execute("""
                UPDATE ACTION 
                SET EVENT_VALUE = :event_value, EVENT_TIMESTAMP = :timestamp 
                WHERE EVENT_ID = :event_id
            """, {
                'event_value': event_value,
                'timestamp': current_time,
                'event_id': existing_event[0]
            })
        else:
            # 새로운 이벤트 삽입
            cursor.execute("""
                INSERT INTO ACTION (USER_ID, MOVIE_ID, EVENT_TYPE, EVENT_VALUE, EVENT_TIMESTAMP) 
                VALUES (:user_id, :movie_id, :event_type, :event_value, :timestamp)
            """, {
                'user_id': user_id,
                'movie_id': movie_id,
                'event_type': event_type,
                'event_value': event_value,
                'timestamp': current_time
            })

        conn.commit()
        print("Event saved successfully with event_value:", event_value)  # 디버깅 메시지

    except cx_Oracle.DatabaseError as e:
        print(f"Database error: {e}")
        conn.rollback()
    finally:
        conn.close()

# 영화 목록 페이지 (# 11/11 수정 --------)
@app.route("/movies")
def movies():
    if "user_id" not in session:
        print("user_id가 세션에 없습니다.")
        flash("세션이 유효하지 않습니다. 코드를 재확인해주세요.")
        return redirect(url_for("login"))
    
    print(f"세션 user_id: {session['user_id']}")

    user_id = session.get("user_id")
    page = request.args.get('page', 1, type=int)
    per_page = 30

    # movies는 반드시 DataFrame이어야 함 (11/11)
    movies = load_movies()
    
    if isinstance(movies, pd.DataFrame):
        movies = movies.to_dict('records') # DataFrame을 딕셔너리 리스트로 변환
    else:
        flash("영화 데이터 로드에 문제가 발생했습니다.")
        return redirect(url_for("index"))
    
    total_movies = len(movies)
    paginated_movies = movies[(page - 1) * per_page:page * per_page]
    total_pages = (total_movies + per_page - 1) // per_page

    conn = get_db_connection()
    cursor = conn.cursor()
    
    # 사용자별 좋아요, 시청 완료 및 별점 데이터 가져오기
    cursor.execute("SELECT MOVIE_ID FROM ACTION WHERE USER_ID = :user_id AND EVENT_TYPE = 'like' AND EVENT_VALUE = 1", {'user_id': user_id})
    liked_movies = {row[0] for row in cursor.fetchall()}

    cursor.execute("SELECT MOVIE_ID FROM ACTION WHERE USER_ID = :user_id AND EVENT_TYPE = 'view' AND EVENT_VALUE = 1", {'user_id': user_id})
    viewed_movies = {row[0] for row in cursor.fetchall()}

    cursor.execute("SELECT MOVIE_ID, EVENT_VALUE FROM ACTION WHERE USER_ID = :user_id AND EVENT_TYPE = 'rating'", {'user_id': user_id})
    ratings = {row[0]: row[1] for row in cursor.fetchall()}
    
    conn.close()

    start_page = max(1, page - 2)
    end_page = min(total_pages, page + 2)
    page_range = list(range(start_page, end_page + 1))

    return render_template(
        "movies.html",
        movies=paginated_movies,
        page=page,
        total_pages=total_pages,
        page_range=page_range,
        liked_movies=liked_movies,
        viewed_movies=viewed_movies,
        ratings=ratings
    )

# 영화추천 코드 최신화 (# 11/11 수정)
@app.route("/recommend")
def recommend():
    if "user_id" not in session:
        return redirect(url_for("login"))

    user_id = session["user_id"]
    print(f"Session user ID in app.py: '{user_id}'")  # 디버깅 코드

    # 상호작용 데이터 로드
    interactions = load_and_preprocess_interactions()
    print("Interactions DataFrame in app.py before passing to model:", interactions.head())
    if interactions is None or interactions.empty:
        print("interactions 데이터프레임이 비어있습니다.")
        flash("상호작용 데이터가 없습니다. 관리자에게 문의하세요.")
        return redirect(url_for("index"))

    # interactions 데이터프레임에 필요한 컬럼이 있는지 확인
    if 'MOVIE_ID' not in interactions.columns or 'EVENT_TYPE' not in interactions.columns:
        print("interactions 데이터프레임에 필요한 컬럼이 없습니다.")
        flash("상호작용 데이터가 올바르지 않습니다. 관리자에게 문의하세요.")
        return redirect(url_for("index"))

    # 영화 데이터 로드
    movies = load_movies()
    if movies is None or movies.empty:
        print("movies 데이터프레임이 비어있습니다.")
        flash("영화 데이터가 없습니다. 관리자에게 문의하세요.")
        return redirect(url_for("index"))

    if 'MOVIE_ID' not in movies.columns:
        print("movies 데이터프레임에 MOVIE_ID 컬럼이 없습니다.")
        flash("영화 데이터가 올바르지 않습니다. 관리자에게 문의하세요.")
        return redirect(url_for("index"))

    # 사용자 데이터 로드
    users = load_users()
    if users is None or users.empty:
        print("users 데이터프레임이 비어있습니다.")
        flash("사용자 데이터가 없습니다. 관리자에게 문의하세요.")
        return redirect(url_for("index"))

    # 영화 순위 계산
    ranked_recommendations = calculate_movie_ranking(interactions, movies)

    print("Interactions DataFrame:", interactions.head())
    print("Movies DataFrame:", movies.head())
    print("Users DataFrame:", users.head())

    # 개인 맞춤형 및 콘텐츠 기반 추천 호출
    personalized, content_based = recommend_movies(model, user_id, interactions, movies, users, top_n=5)

    # 이미 딕셔너리 형태인지 확인 후 변환
    if isinstance(ranked_recommendations, pd.DataFrame):
        ranked_recommendations = ranked_recommendations.to_dict('records')
    if isinstance(personalized, pd.DataFrame):
        personalized = personalized.to_dict('records')
    if isinstance(content_based, pd.DataFrame):
        content_based = content_based.to_dict('records')

    # 디버깅 코드 추가
    print("Personalized recommendations:", personalized)
    print("Content-based recommendations:", content_based)

    # 추천 결과를 템플릿에 전달
    return render_template("recommend.html", 
                           ranked_recommendations=ranked_recommendations, 
                           personalized=personalized, 
                           content_based=content_based)


# 상호작용 처리 라우트 ( # 11/10 수정------------)
@app.route('/handle_event', methods=['POST'])
def handle_event():
    data = request.json
    event_type = data.get('event_type')
    event_value = data.get('event_value')
    movie_id = data.get('movie_id')
    user_id = session.get('user_id')  # 세션에서 user_id 가져오기

    if not user_id:
        return jsonify({'error': 'User not logged in'}), 403

    response = {}

    conn = get_db_connection()
    cursor = conn.cursor()

    if event_type == 'like':
        # 현재 좋아요 상태를 확인하고 토글
        cursor.execute("""
            SELECT EVENT_VALUE FROM ACTION 
            WHERE USER_ID = :user_id AND MOVIE_ID = :movie_id AND EVENT_TYPE = 'like'
        """, {'user_id': user_id, 'movie_id': movie_id})
        row = cursor.fetchone()

        if row:
            new_value = 0 if row[0] == 1 else 1  # 현재 값이 1이면 0으로, 0이면 1로 반전
            cursor.execute("""
                UPDATE ACTION
                SET EVENT_VALUE = :new_value, EVENT_TIMESTAMP = CURRENT_TIMESTAMP
                WHERE USER_ID = :user_id AND MOVIE_ID = :movie_id AND EVENT_TYPE = 'like'
            """, {'new_value': new_value, 'user_id': user_id, 'movie_id': movie_id})
        else:
            new_value = 1  # 좋아요 기록이 없으면 1로 설정
            cursor.execute("""
                INSERT INTO ACTION (USER_ID, MOVIE_ID, EVENT_TYPE, EVENT_VALUE, EVENT_TIMESTAMP)
                VALUES (:user_id, :movie_id, 'like', :new_value, CURRENT_TIMESTAMP)
            """, {'user_id': user_id, 'movie_id': movie_id, 'new_value': new_value})

        response['event_value'] = new_value  # 새로운 좋아요 상태를 응답에 포함

    elif event_type == 'view':
        # 시청 완료 상태 업데이트 (한 번 시청 완료 시 변경 불가)
        cursor.execute("""
            SELECT EVENT_VALUE FROM ACTION
            WHERE USER_ID = :user_id AND MOVIE_ID = :movie_id AND EVENT_TYPE = 'view'
        """, {'user_id': user_id, 'movie_id': movie_id})
        row = cursor.fetchone()

        if not row:
            # 시청 완료 기록이 없을 때에만 기록 추가
            cursor.execute("""
                INSERT INTO ACTION (USER_ID, MOVIE_ID, EVENT_TYPE, EVENT_VALUE, EVENT_TIMESTAMP)
                VALUES (:user_id, :movie_id, 'view', 1, CURRENT_TIMESTAMP)
            """, {'user_id': user_id, 'movie_id': movie_id})
            response['success'] = True

    elif event_type == 'rating':
        # 별점 기록을 새로 추가하거나 업데이트
        cursor.execute("""
            SELECT EVENT_VALUE FROM ACTION
            WHERE USER_ID = :user_id AND MOVIE_ID = :movie_id AND EVENT_TYPE = 'rating'
        """, {'user_id': user_id, 'movie_id': movie_id})
        row = cursor.fetchone()

        if not row:
            # 별점 기록이 없을 때만 기록 추가
            cursor.execute("""
                INSERT INTO ACTION (USER_ID, MOVIE_ID, EVENT_TYPE, EVENT_VALUE, EVENT_TIMESTAMP)
                VALUES (:user_id, :movie_id, 'rating', :event_value, CURRENT_TIMESTAMP)
            """, {'user_id': user_id, 'movie_id': movie_id, 'event_value': event_value})
            response['success'] = True
        else:
            response['success'] = False  # 별점이 이미 존재할 경우 업데이트 안 함

    conn.commit()
    conn.close()

    return jsonify(response), 200


if __name__ == "__main__":
    app.run(debug=True)