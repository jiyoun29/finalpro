import cx_Oracle
import pandas as pd
import os
import warnings

# 경고 무시 설정
warnings.filterwarnings("ignore", category=UserWarning, message="pandas only supports SQLAlchemy connectable")

# Oracle DB 커넥션 함수
def get_db_connection():
    dsn = cx_Oracle.makedsn("localhost", "1521", sid="xe")
    return cx_Oracle.connect("c##scott", "tiger", dsn)

# 사용자 데이터 로드 함수
def load_users():
    with get_db_connection() as conn:
        query = "SELECT * FROM USER_TABLE"  # 테이블 이름 수정
        users = pd.read_sql_query(query, con=conn)
        users['USER_IDX'] = pd.factorize(users['USER_ID'])[0]  # [0]을 추가하여 첫 번째 반환 값만 할당
    return users
 
# 영화 데이터 로드 함수 (# 11/08 GENRE_NAME(장르) 추가--------- )
def load_movies():
    with get_db_connection() as conn: # 여기서 평균 평점 가져옴 (# 11/11)
        query = """
            SELECT M.MOVIE_ID, M.MOVIE_NAME, M.OPEN_DATE, M.GENRE_NAME,
                   COALESCE(AVG(A.EVENT_VALUE), 0) AS RATING
            FROM MOVIE M
            LEFT JOIN ACTION A ON M.MOVIE_ID = A.MOVIE_ID AND A.EVENT_TYPE = 'rating'
            GROUP BY M.MOVIE_ID, M.MOVIE_NAME, M.OPEN_DATE, M.GENRE_NAME
        """
        movies_df = pd.read_sql_query(query, con=conn)

    def match_image(movie_name):
        image_folder = 'static/images'
        for file in os.listdir(image_folder):
            if movie_name in file:
                return file
        return "default.jpg"

    # 날짜 형식 변환 및 이미지 매칭
    movies_df['image'] = movies_df['MOVIE_NAME'].apply(match_image)
    movies_df['MOVIE_IDX'] = pd.factorize(movies_df['MOVIE_ID'])[0]
    movies_df['MOVIE_CODE'] = movies_df['MOVIE_IDX']  # MOVIE_CODE 생성
    
    movies_df['OPEN_DATE'] = pd.to_datetime(movies_df['OPEN_DATE'], format='%Y-%m', errors='coerce').dt.strftime('%Y-%m')

    return movies_df # DataFrame 반환, 필요 시 .to_dict('records') 변환 필요 

# 영화 데이터 로드 함수 (# 11/08 GENRE_NAME(개봉일) 추가--------- )

# 이벤트 값 전처리 함수(모델에서 사용)
def preprocess_event_value(row):
    """
    이벤트 타입에 따라 EVENT_VALUE를 정규화하는 함수
    """
    if row['EVENT_TYPE'] == 'like':
        return row['EVENT_VALUE']  # 좋아요 (0 또는 1)
    elif row['EVENT_TYPE'] == 'rating':
        return row['EVENT_VALUE'] / 5  # 평점 (0 ~ 5 사이의 값 → 0 ~ 1 사이로 정규화)
    elif row['EVENT_TYPE'] == 'view':
        return row['EVENT_VALUE']  # 시청 기록 (0 또는 1)

# # 이벤트 데이터 로드 함수 (# 11/11 이거 안 쓰는듯 해서, 주석 처리함)
# def load_event_data(movie_id, event_type):
#     with get_db_connection() as conn:
#         query = """
#             SELECT COALESCE(AVG(EVENT_VALUE), 0) AS AVG_RATING
#             FROM ACTION
#             WHERE MOVIE_ID = :MOVIE_ID AND EVENT_TYPE = :EVENT_TYPE
#         """
#         cursor = conn.cursor()
#         cursor.execute(query, {'MOVIE_ID': movie_id, 'EVENT_TYPE': event_type})
#         result = cursor.fetchone()
        
#     return float(result[0]) if result else 0
#----------------------------------------------

# 상호작용 데이터 로드 및 전처리 함수(app.py에서 호출하여 model.py와 추천 페이지 결과값 만들어주는 데이터 보내주는 함수)
def load_and_preprocess_interactions():
    with get_db_connection() as conn:
        query = """
            SELECT USER_ID, MOVIE_ID, EVENT_TYPE, EVENT_VALUE
            FROM ACTION
        """
        actions = pd.read_sql_query(query, con=conn)
        
    # 컬럼명을 대문자로 변환
    actions.columns = actions.columns.str.upper()
    # 이벤트 값 전처리
    actions['EVENT_VALUE'] = actions.apply(preprocess_event_value, axis=1)

    # 필요한 컬럼이 모두 있는지 확인(디버깅용 코드임)
    required_columns = {'USER_ID', 'MOVIE_ID', 'EVENT_TYPE', 'EVENT_VALUE'}
    if not required_columns.issubset(actions.columns):
        raise KeyError("interactions 데이터프레임에 필요한 컬럼이 없습니다. "
                       f"필요한 컬럼: {required_columns}, 현재 컬럼: {set(actions.columns)}")

    # User, Movie ID를 수치형 코드로 변환 
    actions['USER_CODE'] = actions['USER_ID'].astype('category').cat.codes
    actions['MOVIE_CODE'] = actions['MOVIE_ID'].astype('category').cat.codes

    return actions[['USER_ID', 'USER_CODE', 'MOVIE_ID', 'MOVIE_CODE', 'EVENT_TYPE', 'EVENT_VALUE']] # 리턴값 추가

# # 사용자와 영화 ID를 불러오는 함수
# def load_user_and_movie_ids():
#     with get_db_connection() as conn:
#         user_ids = pd.read_sql_query("SELECT DISTINCT USER_ID FROM USER_TABLE", con=conn)  # 테이블 이름 수정
#         movie_ids = pd.read_sql_query("SELECT DISTINCT MOVIE_ID FROM MOVIE", con=conn)     # 테이블 이름 수정
#     return user_ids['USER_ID'].tolist(), movie_ids['MOVIE_ID'].tolist()


# 사용자와 영화 ID를 불러오는 함수 (# 11/11 코드 변경)
def load_user_and_movie_ids():
    with get_db_connection() as conn:
        try:
            # 사용자 ID와 영화 ID 데이터 불러오기
            user_ids = pd.read_sql_query("SELECT DISTINCT USER_ID FROM USER_TABLE", conn)
            movie_ids = pd.read_sql_query("SELECT DISTINCT MOVIE_ID FROM MOVIE", conn)
            
            
            #print("User IDs:", user_ids['USER_ID'].tolist())  # 디버깅용 출력
            #print("Movie IDs:", movie_ids['MOVIE_ID'].tolist())  # 디버깅용 출력

            return user_ids['USER_ID'].tolist(), movie_ids['MOVIE_ID'].tolist()
        
        except Exception as e:
            print(f"Error loading user and movie IDs: {e}")
            return [], []  # 오류 발생 시 빈 리스트 반환