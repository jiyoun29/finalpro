from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import cx_Oracle
import pandas as pd
from datetime import datetime
import os

app = Flask(__name__)
app.secret_key = "your_secret_key"

# 오라클 DB 설정
dsn = cx_Oracle.makedsn("localhost", "1521", sid="xe")
conn = cx_Oracle.connect("c##scott", "tiger", dsn)

# 사용자 데이터 로드 함수
def load_users():
    users = pd.read_sql("SELECT * FROM user_table", con=conn)
    return users

# 사용자 로그인 확인 함수
def login_user(account_id, user_df):
    user = user_df[user_df['ACCOUNT_ID'] == account_id]
    return user.iloc[0] if not user.empty else None

# 영화 데이터 로드 함수
def load_movies():
    query = """
        SELECT M.MOVIE_ID, M.MOVIE_NAME, M.OPEN_DATE, 
               COALESCE(AVG(A.EVENT_VALUE), 0) AS RATING
        FROM MOVIE M
        LEFT JOIN ACTION A ON M.MOVIE_ID = A.MOVIE_ID AND A.EVENT_TYPE = 'rating'
        GROUP BY M.MOVIE_ID, M.MOVIE_NAME, M.OPEN_DATE
    """
    movies_df = pd.read_sql(query, con=conn)

    def match_image(movie_name):
        image_folder = 'static/images'
        best_match_file = ""
        best_similarity = 0
        for file in os.listdir(image_folder):
            similarity = len(set(movie_name).intersection(set(file))) / len(set(movie_name).union(set(file)))
            if similarity > best_similarity:
                best_similarity = similarity
                best_match_file = file
        return best_match_file if best_match_file else "default.jpg"

    movies_df['image'] = movies_df['MOVIE_NAME'].apply(match_image)
    movies_df['OPEN_DATE'] = movies_df['OPEN_DATE'].dt.strftime('%Y-%m')
    return movies_df.to_dict('records')

# ACTION 테이블에 이벤트를 저장하는 함수
def save_event(user_id, movie_id, event_type, event_value):
    current_time = datetime.now()
    try:
        with conn.cursor() as cursor:
            cursor.execute("""
                MERGE INTO ACTION tgt
                USING (SELECT :user_id AS USER_ID, :movie_id AS MOVIE_ID, :event_type AS EVENT_TYPE FROM DUAL) src
                ON (tgt.USER_ID = src.USER_ID AND tgt.MOVIE_ID = src.MOVIE_ID AND tgt.EVENT_TYPE = src.EVENT_TYPE)
                WHEN MATCHED THEN
                    UPDATE SET tgt.EVENT_VALUE = :event_value, tgt.EVENT_TIMESTAMP = :timestamp
                WHEN NOT MATCHED THEN
                    INSERT (USER_ID, MOVIE_ID, EVENT_TYPE, EVENT_VALUE, EVENT_TIMESTAMP)
                    VALUES (:user_id, :movie_id, :event_type, :event_value, :timestamp)
            """, {
                'user_id': user_id,
                'movie_id': movie_id,
                'event_type': event_type,
                'event_value': event_value,
                'timestamp': current_time
            })
        conn.commit()
    except cx_Oracle.DatabaseError as e:
        error, = e.args
        print("Database error:", error.message)
        conn.rollback()
        return False
    return True

# 이벤트 처리 라우트
@app.route('/handle_event', methods=['POST'])
def handle_event():
    data = request.json
    event_type = data.get('event_type')
    event_value = data.get('event_value')
    movie_id = data.get('movie_id')
    user = session.get('user')
    user_id = user['USER_ID'] if user else None

    if not user_id:
        return jsonify({'error': 'User not logged in'}), 403

    response = {}

    if event_type == 'like':
        new_value = 1 if event_value == 0 else 0
        response['event_value'] = new_value
        response['icon'] = '❤' if new_value == 1 else '♡'
        save_event(user_id, movie_id, 'like', new_value)

    elif event_type == 'view':
        new_value = 1 if event_value == 0 else 0
        response['event_value'] = new_value
        response['status'] = 'watched' if new_value == 1 else 'not watched'
        save_event(user_id, movie_id, 'view', new_value)

    elif event_type == 'rating':
        # 새로운 별점 이벤트 처리
        save_event(user_id, movie_id, 'rating', event_value)
        
        # 새로운 평균 평점 계산
        query = """
            SELECT COALESCE(AVG(EVENT_VALUE), 0) AS AVG_RATING
            FROM ACTION
            WHERE MOVIE_ID = :movie_id AND EVENT_TYPE = 'rating'
        """
        cursor = conn.cursor()
        cursor.execute(query, {'movie_id': movie_id})
        result = cursor.fetchone()
        avg_rating = result[0] if result else 0  # 결과가 없을 경우 기본값 0을 사용
        cursor.close()
        response['new_rating'] = float(round(avg_rating, 1))  # float으로 변환하여 JSON 직렬화 가능하게 변경

    return jsonify(response), 200

# 기본 페이지 라우트
@app.route("/")
def index():
    if "user" in session:
        return redirect(url_for("movies"))
    return redirect(url_for("login"))

# 로그인 페이지
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        account_id = request.form.get("account_id")
        user_df = load_users()
        user = login_user(account_id, user_df)

        if user is not None:
            session['user'] = user.to_dict()
            return redirect(url_for("movies"))
        else:
            flash("로그인 실패: 잘못된 Account ID입니다.")
            return redirect(url_for("login"))

    return render_template("login.html")

# 영화 목록 페이지
@app.route("/movies")
def movies():
    if "user" not in session:
        return redirect(url_for("login"))

    page = request.args.get('page', 1, type=int)
    per_page = 18
    movies = load_movies()
    total_movies = len(movies)
    paginated_movies = movies[(page - 1) * per_page:page * per_page]
    total_pages = (total_movies + per_page - 1) // per_page

    return render_template("index.html", movies=paginated_movies, page=page, total_pages=total_pages)

# 로그아웃 기능
@app.route("/logout")
def logout():
    session.pop("user", None)
    return redirect(url_for("login"))

if __name__ == "__main__":
    app.run(debug=True)
