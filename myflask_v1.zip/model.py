import torch
import torch.nn as nn
import os
import pandas as pd

# 모델 저장 경로
MODEL_PATH = 'c:\\myflask_v1\\static\\trained_model.pt'

# NCF- 하이브리드 모델 정의
class HybridNCFModel(nn.Module):
    def __init__(self, num_users, num_movies, embedding_dim=50):
        super(HybridNCFModel, self).__init__()
        self.user_embedding = nn.Embedding(num_users, embedding_dim)
        self.movie_embedding = nn.Embedding(num_movies, embedding_dim)
        self.fc1 = nn.Linear(embedding_dim * 2, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 1)
    
    def forward(self, user, movie):
        user_embedded = self.user_embedding(user)
        movie_embedded = self.movie_embedding(movie)
        x = torch.cat([user_embedded, movie_embedded], dim=-1)
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return torch.sigmoid(self.fc3(x)).view(-1)

    def expand_embeddings(self, new_num_users, new_num_movies):
        # 유저 임베딩 크기 조정
        if new_num_users != self.user_embedding.num_embeddings:
            new_user_embedding = nn.Embedding(new_num_users, self.user_embedding.embedding_dim)
            min_user_count = min(new_num_users, self.user_embedding.num_embeddings)
            new_user_embedding.weight.data[:min_user_count] = self.user_embedding.weight.data[:min_user_count]
            self.user_embedding = new_user_embedding
        
        # 영화 임베딩 크기 조정
        if new_num_movies != self.movie_embedding.num_embeddings:
            new_movie_embedding = nn.Embedding(new_num_movies, self.movie_embedding.embedding_dim)
            min_movie_count = min(new_num_movies, self.movie_embedding.num_embeddings)
            new_movie_embedding.weight.data[:min_movie_count] = self.movie_embedding.weight.data[:min_movie_count]
            self.movie_embedding = new_movie_embedding

# 모델 초기화 및 로드 함수
def load_or_initialize_model(num_users, num_movies, model_path=MODEL_PATH):
    model = HybridNCFModel(num_users, num_movies)
    
    if os.path.exists(model_path):
        checkpoint = torch.load(model_path, map_location=torch.device('cpu'))
        # 임베딩 레이어 크기 조정
        model.expand_embeddings(num_users, num_movies)
        
        # 기존 임베딩 레이어를 제외한 나머지 가중치 로드
        filtered_checkpoint = {k: v for k, v in checkpoint.items() if "embedding" not in k}
        model.load_state_dict(filtered_checkpoint, strict=False)
        
        print(f"Model loaded with adjusted embeddings for {num_users} users and {num_movies} movies.")
    else:
        print("No saved model found. Initializing a new model.")
    
    model.eval()
    
    return model

# 모델 저장 함수
def save_model(model, model_path=MODEL_PATH):
    torch.save(model.state_dict(), model_path)
    print(f"Model saved at {model_path}")


# 순위 기반 알고리즘
def calculate_movie_ranking(interactions, movies):
    # 컬럼 존재 여부 확인
    if 'EVENT_TYPE' not in interactions.columns or 'MOVIE_ID' not in interactions.columns:
        raise KeyError("interactions 데이터프레임에 'EVENT_TYPE' 또는 'MOVIE_ID' 컬럼이 없습니다.")
    
    try:
        likes = interactions[interactions['EVENT_TYPE'] == 'like'].groupby('MOVIE_ID').size() * 0.2
        views = interactions[interactions['EVENT_TYPE'] == 'view'].groupby('MOVIE_ID').size() * 0.3
        ratings = interactions[interactions['EVENT_TYPE'] == 'rating'].groupby('MOVIE_ID')['EVENT_VALUE'].mean() * 0.5

        ranking_score = likes.add(views, fill_value=0).add(ratings, fill_value=0)
        ranked_movies = ranking_score.sort_values(ascending=False).index.tolist()
        ranked_movies_info = [
            movies[movies['MOVIE_ID'] == movie_id].iloc[0].to_dict() 
            for movie_id in ranked_movies if movie_id in movies['MOVIE_ID'].values
        ]

        # 동일한 ranking_score를 가진 영화들이 있을 때 무작위로 순서를 섞기
        import random
        if len(ranked_movies_info) > 1:
            random.shuffle(ranked_movies_info)

        # 상위 5개만 반환
        return ranked_movies_info[:5]
    except KeyError as e:
        print(f"KeyError 발생: {e}")
        return []
    
def recommend_movies(model, user_id, interactions, movies, user_features, top_n=5):
    # 데이터 타입 일치
    interactions['USER_ID'] = interactions['USER_ID'].astype(str)
    user_id = str(user_id)

    # user_interactions 초기화 및 필터링
    user_interactions = interactions[interactions['USER_ID'] == user_id]
    print("Filtered interactions for user_id:", user_interactions)

    personalized_recommendations = []
    content_based_recommendations = []

    # 1순위: NCF 협업필터링 기반 추천
    if not user_interactions.empty:
        user_code = user_interactions['USER_CODE'].iloc[0]  # 첫 번째 USER_CODE 사용
        print("User code for tensor:", user_code)  # 디버깅 코드

        try:
            user_tensor = torch.tensor([user_code], dtype=torch.long)
            print("User tensor created successfully:", user_tensor)  # 디버깅 코드
        except Exception as e:
            print("Error creating user tensor:", e)  # 에러 메시지 출력
            return [], []

        interacted_movies = user_interactions['MOVIE_CODE'].unique()
        model.eval()

        scores = []
        with torch.no_grad():
            for movie_code in movies['MOVIE_CODE'].unique():
                if movie_code not in interacted_movies:
                    movie_tensor = torch.tensor([movie_code], dtype=torch.long)
                    score = model(user_tensor, movie_tensor).item()
                    scores.append((movie_code, score))

        top_movies = sorted(scores, key=lambda x: x[1], reverse=True)[:10]  # 10개 리스트를 반환
        personalized_recommendations = [movies[movies['MOVIE_CODE'] == m[0]].iloc[0].to_dict() for m in top_movies]

    # 2순위: 콘텐츠 기반 추천 (개인 맞춤형 추천과 중복되지 않도록)
    if not user_interactions.empty or len(personalized_recommendations) < 10:
        user_info = user_features[user_features['USER_ID'] == user_id].iloc[0]
        user_age = user_info['AGE']
        user_gender = user_info['GENDER']
        age_range = 5  # ±5살 범위

        similar_users = user_features[
            (user_features['GENDER'] == user_gender) &
            (user_features['AGE'] >= user_age - age_range) &
            (user_features['AGE'] <= user_age + age_range)
        ]

        similar_user_ids = similar_users['USER_ID'].values
        similar_interactions = interactions[interactions['USER_ID'].isin(similar_user_ids)]
        high_rated_movies = similar_interactions[similar_interactions['EVENT_VALUE'] >= 0.8]['MOVIE_CODE'].drop_duplicates()

        content_based_recommendations = [
            movies[movies['MOVIE_CODE'] == movie_code].iloc[0].to_dict()
            for movie_code in high_rated_movies
            if movie_code in movies['MOVIE_CODE'].values and
            movie_code not in [m['MOVIE_CODE'] for m in personalized_recommendations]
        ][:10]  # 10개 리스트를 반환

    # 개인 맞춤형 추천이 충분하지 않을 경우 콘텐츠 기반 추천으로 채우기
    if len(personalized_recommendations) < 5:
        remaining_slots = 5 - len(personalized_recommendations)
        additional_content_based = content_based_recommendations[:remaining_slots]
        personalized_recommendations.extend(additional_content_based)
        content_based_recommendations = content_based_recommendations[remaining_slots:]

    # 최종 반환
    return personalized_recommendations[:5], content_based_recommendations[:5]
