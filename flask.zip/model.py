import torch
import torch.nn as nn
import os
import pandas as pd

# 모델 저장 경로
MODEL_PATH = 'c:\\stream\\trained_model.pt'

# NCF 모델 정의
class DynamicNCFModel(nn.Module):
    def __init__(self, num_users, num_movies, embedding_dim=50):
        super(DynamicNCFModel, self).__init__()
        self.user_embedding = nn.Embedding(num_users, embedding_dim)
        self.movie_embedding = nn.Embedding(num_movies, embedding_dim)
        self.fc1 = nn.Linear(embedding_dim * 2, 128)
        self.fc2 = nn.Linear(128, 64)
        self.fc3 = nn.Linear(64, 1)
    
    def forward(self, user, movie):
        user_embedded = self.user_embedding(user)
        movie_embedded = self.movie_embedding(movie)
        x = torch.cat([user_embedded, movie_embedded], dim=-1)
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        return torch.sigmoid(self.fc3(x)).view(-1)

    def expand_embeddings(self, new_num_users, new_num_movies):
        # 유저 임베딩 크기 조정
        if new_num_users != self.user_embedding.num_embeddings:
            new_user_embedding = nn.Embedding(new_num_users, self.user_embedding.embedding_dim)
            min_user_count = min(new_num_users, self.user_embedding.num_embeddings)
            new_user_embedding.weight.data[:min_user_count] = self.user_embedding.weight.data[:min_user_count]
            self.user_embedding = new_user_embedding
        
        # 영화 임베딩 크기 조정
        if new_num_movies != self.movie_embedding.num_embeddings:
            new_movie_embedding = nn.Embedding(new_num_movies, self.movie_embedding.embedding_dim)
            min_movie_count = min(new_num_movies, self.movie_embedding.num_embeddings)
            new_movie_embedding.weight.data[:min_movie_count] = self.movie_embedding.weight.data[:min_movie_count]
            self.movie_embedding = new_movie_embedding

# 모델 초기화 및 로드 함수
def load_or_initialize_model(num_users, num_movies, model_path=MODEL_PATH):
    model = DynamicNCFModel(num_users, num_movies)
    
    if os.path.exists(model_path):
        checkpoint = torch.load(model_path, map_location=torch.device('cpu'))
        
        # 임베딩 레이어 크기 조정
        model.expand_embeddings(num_users, num_movies)
        
        # 기존 임베딩 레이어를 제외한 나머지 가중치 로드
        filtered_checkpoint = {k: v for k, v in checkpoint.items() if "embedding" not in k}
        model.load_state_dict(filtered_checkpoint, strict=False)
        
        print(f"Model loaded with adjusted embeddings for {num_users} users and {num_movies} movies.")
    else:
        print("No saved model found. Initializing a new model.")
    
    model.eval()
    return model

# 모델 저장 함수
def save_model(model, model_path=MODEL_PATH):
    torch.save(model.state_dict(), model_path)
    print(f"Model saved at {model_path}")

# 추천 함수에서 interactions 데이터프레임에 맞는 컬럼 이름 사용
def recommend_similar_movies(model, interactions, movies, user_id, top_n=5):
    """
    주어진 사용자에 대해 상위 N개의 추천 영화를 반환합니다.
    """
    # interactions 데이터프레임의 컬럼 확인 (디버깅용)
    print("interactions 컬럼:", interactions.columns)

    # 올바른 컬럼 이름 사용
    user_interactions = interactions[interactions['USER_CODE'] == user_id]
    interacted_movies = user_interactions['MOVIE_CODE'].unique()

    if user_interactions.empty:
        return []

    user_tensor = torch.tensor([user_id], dtype=torch.long)
    model.eval()

    scores = []
    with torch.no_grad():
        for movie_code in interactions['MOVIE_CODE'].unique():
            if movie_code not in interacted_movies:
                movie_tensor = torch.tensor([movie_code], dtype=torch.long)
                score = model(user_tensor, movie_tensor).item()
                scores.append((movie_code, score))

    # 평점 상위 N개의 영화 추천
    top_movies = sorted(scores, key=lambda x: x[1], reverse=True)[:top_n]
    recommended_movies = [movie for movie in movies if movie['MOVIE_ID'] in [m[0] for m in top_movies]]
    return recommended_movies

