import cx_Oracle
import pandas as pd
import os

# Oracle DB 커넥션 함수
def get_db_connection():
    dsn = cx_Oracle.makedsn("localhost", "1521", sid="xe")
    return cx_Oracle.connect("c##scott", "tiger", dsn)

# 사용자 데이터 로드 함수
def load_users():
    with get_db_connection() as conn:
        query = "SELECT * FROM USER_TABLE"  # 테이블 이름 수정
        users = pd.read_sql_query(query, con=conn)
    return users

# 영화 데이터 로드 함수
def load_movies():
    with get_db_connection() as conn:
        query = """
            SELECT M.MOVIE_ID, M.MOVIE_NAME, M.OPEN_DATE, 
                   COALESCE(AVG(A.EVENT_VALUE), 0) AS RATING
            FROM MOVIE M
            LEFT JOIN ACTION A ON M.MOVIE_ID = A.MOVIE_ID AND A.EVENT_TYPE = 'rating'
            GROUP BY M.MOVIE_ID, M.MOVIE_NAME, M.OPEN_DATE
        """
        movies_df = pd.read_sql_query(query, con=conn)

    def match_image(movie_name):
        image_folder = 'static/images'
        best_match_file = ""
        best_similarity = 0
        for file in os.listdir(image_folder):
            similarity = len(set(movie_name).intersection(set(file))) / len(set(movie_name).union(set(file)))
            if similarity > best_similarity:
                best_similarity = similarity
                best_match_file = file
        return best_match_file if best_match_file else "default.jpg"

    # 날짜 형식 변환 및 이미지 매칭
    movies_df['OPEN_DATE'] = pd.to_datetime(movies_df['OPEN_DATE'], errors='coerce').dt.strftime('%Y-%m')
    movies_df['image'] = movies_df['MOVIE_NAME'].apply(match_image)
    
    return movies_df.to_dict('records')

# 이벤트 값 전처리 함수
def preprocess_event_value(row):
    """
    이벤트 타입에 따라 EVENT_VALUE를 정규화하는 함수
    """
    if row['EVENT_TYPE'] == 'like':
        return row['EVENT_VALUE']  # 좋아요 (0 또는 1)
    elif row['EVENT_TYPE'] == 'rating':
        return row['EVENT_VALUE'] / 5  # 평점 (0 ~ 5 사이의 값 → 0 ~ 1 사이로 정규화)
    elif row['EVENT_TYPE'] == 'view':
        return row['EVENT_VALUE']  # 시청 기록 (0 또는 1)

# 이벤트 데이터 로드 함수
def load_event_data(movie_id, event_type):
    with get_db_connection() as conn:
        query = """
            SELECT COALESCE(AVG(EVENT_VALUE), 0) AS AVG_RATING
            FROM ACTION
            WHERE MOVIE_ID = :MOVIE_ID AND EVENT_TYPE = :EVENT_TYPE
        """
        cursor = conn.cursor()
        cursor.execute(query, {'MOVIE_ID': movie_id, 'EVENT_TYPE': event_type})
        result = cursor.fetchone()
        
    return float(result[0]) if result else 0

# 상호작용 데이터 로드 및 전처리 함수
def load_and_preprocess_interactions():
    """
    사용자 상호작용 데이터를 모두 불러와 전처리한 후 반환하는 함수
    """
    with get_db_connection() as conn:
        query = "SELECT USER_ID, MOVIE_ID, EVENT_TYPE, EVENT_VALUE FROM ACTION"
        actions = pd.read_sql_query(query, con=conn)
        
    # 컬럼명을 대문자로 변환
    actions.columns = actions.columns.str.upper()    

    # 이벤트 값 전처리
    actions['EVENT_VALUE'] = actions.apply(preprocess_event_value, axis=1)

    # User, Movie ID를 수치형 코드로 변환
    actions['USER_CODE'] = actions['USER_ID'].astype('category').cat.codes
    actions['MOVIE_CODE'] = actions['MOVIE_ID'].astype('category').cat.codes

    # # interactions 데이터프레임에 올바른 컬럼이 있는지 확인
    # print(actions.head())  # 로그 출력 확인

    return actions[['USER_ID', 'USER_CODE', 'MOVIE_CODE', 'EVENT_VALUE']] #USER_ID 추가하는 맞냐GPT야?

# 사용자와 영화 ID를 불러오는 함수
def load_user_and_movie_ids():
    with get_db_connection() as conn:
        user_ids = pd.read_sql_query("SELECT DISTINCT USER_ID FROM USER_TABLE", con=conn)  # 테이블 이름 수정
        movie_ids = pd.read_sql_query("SELECT DISTINCT MOVIE_ID FROM MOVIE", con=conn)     # 테이블 이름 수정
    return user_ids['USER_ID'].tolist(), movie_ids['MOVIE_ID'].tolist()